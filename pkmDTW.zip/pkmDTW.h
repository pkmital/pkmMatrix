// -----------------------------------------------------------------------------
//  pkmDTW.h
//  pkmMatrix
//
//  Created by Parag Mital on 10/19/12.
//  Copyright (c) 2012 Parag K Mital. All rights reserved.
//
// -----------------------------------------------------------------------------

#pragma once

#include "pkmMatrix.h"
#include "ofUtils.h"

using namespace pkm;

// -----------------------------------------------------------------------------
class pkmDTW
{
public:
    // -------------------------------------------------------------------------
    pkmDTW()
    {
        bSetQuery = false;
        bHaveCandidates = false;
        bUseZNormalize = false;
        
        range = 0.7;
        
        bestSoFar = INFINITY;
    }
    // -------------------------------------------------------------------------
    
    // -------------------------------------------------------------------------
    //  Change the possible range of the warping envelope
    //
    //  'r' is a floating point value within (0, 1) 
    //  This value determines how much the warping is allowed to move from the diagonal
    void setRange(float r)
    {
        range = r;
    }
    // -------------------------------------------------------------------------
    
    // -------------------------------------------------------------------------
    //  Add elements to the database of possible candidates
    //
    //  'candidate': size is frames x dimensions
    // -------------------------------------------------------------------------
    void addToDatabase(const Mat &el)
    {
        candidates.push_back(el);
        
        bHaveCandidates = true;
    }
    // -------------------------------------------------------------------------
    
    
    // -------------------------------------------------------------------------
    void getNearestCandidate(const Mat &q, 
                             float &distance, 
                             int &subscript, 
                             vector<int> &bestPathI,  // candidate's frame   (source)
                             vector<int> &bestPathJ)  // query's frame       (target)
    {
        if (!bHaveCandidates) {
            cout << "[ERROR::pkmDTW]: Add sequences to the database first using pkmDTW::addToDatabase(el)!" << endl;
            return;
        }
        // establish the query
        setQuery(q);
        subscript = 0;
        // search all candidates linearly
        for (int i = 0; i < candidates.size(); i++) 
        {
            vector<int> pathI, pathJ;    
            Mat differenceMatrix, dtwDistance;
            differenceMatrix = computeDifferenceMatrix(candidates[i]);
            float thisDistance = dtw(q, candidates[i], differenceMatrix, dtwDistance, pathI, pathJ);

            //cout << "i: " << i << endl;
            //dtwDistance.print();
            if (thisDistance < bestSoFar) 
            {
                bestSoFar = thisDistance;
                bestPathI = pathI;
                bestPathJ = pathJ;
                subscript = i;
            }
        }
        distance = bestSoFar;
        bestSoFar = INFINITY;
        
        
    }
    // -------------------------------------------------------------------------
    
    // -------------------------------------------------------------------------
    void getNearestCandidateEuclidean(const Mat &q, 
                                      float &distance, 
                                      int &subscript) 
    {
        if (!bHaveCandidates) {
            cout << "[ERROR::pkmDTW]: Add sequences to the database first using pkmDTW::addToDatabase(el)!" << endl;
            return;
        }
        subscript = 0;
        Mat query = q;
        Mat distanceMatrix = Mat(q.rows, q.cols);
        // search all candidates linearly
        for (int i = 0; i < candidates.size(); i++) 
        {
            query.subtract(candidates[i], distanceMatrix);
            distanceMatrix.abs();
            Mat distance2 = distanceMatrix.sum(false);
            float thisDistance = Mat::sum(distance2);
            if (thisDistance < bestSoFar) 
            {
                bestSoFar = thisDistance;
                subscript = i;
            }
        }
        distance = bestSoFar;
        bestSoFar = INFINITY;
    }
    // -------------------------------------------------------------------------
  
    
    // -------------------------------------------------------------------------
    void save()
    {
        FILE *fp;
        fp = fopen(ofToDataPath("dtwDatabase/dtw.txt").c_str(), "w");
        fprintf(fp, "%d", candidates.size());
        fclose(fp);
        for (int i = 0; i < candidates.size(); i++) {
            char buf[256];
            sprintf(buf, "dtwDatabase/candidate%08d.mat", i);
            candidates[i].save(ofToDataPath(buf));
        }
    }
    // -------------------------------------------------------------------------
    
    
    // -------------------------------------------------------------------------
    void load()
    {
        int numCamdidates = 0;
        FILE *fp;
        fp = fopen(ofToDataPath("dtwDatabase/dtw.txt").c_str(), "r");
        fscanf(fp, "%d", &numCamdidates);
        fclose(fp);
        candidates.resize(numCamdidates);
        for (int i = 0; i < numCamdidates; i++) {
            char buf[256];
            sprintf(buf, "dtwDatabase/candidate%08d.mat", i);
            candidates[i].load(ofToDataPath(buf));
        }
        
        if (numCamdidates > 0) {
            bHaveCandidates = true;
        }
    }
    // -------------------------------------------------------------------------
    
protected:
    
    // -------------------------------------------------------------------------
    // Query is a matrix of size T x D,
    // T is the number of frames or time-steps
    // D is the dimension of each data point
    // -------------------------------------------------------------------------
    void setQuery(const Mat &q)
    {
        query = q;
        if(bUseZNormalize)
        {
            query.zNormalizeEachCol();
        }
        queryTransposed = query;
        queryTransposed.setTranspose();
        
        Mat temp = query;
        temp.sqr();
        queryNormalization = temp.sum(false);
        queryNormalization.sqrt();
        queryNormalization.setTranspose();
        
        bSetQuery = true;
    }
    // -------------------------------------------------------------------------
    
    
    // -------------------------------------------------------------------------
    // Compare stored query with the incoming matrix candidate
    // 
    //  'candidate': size is frames x dimensions
    //  'differenceMatrix': size will be candidate's rows x query's rows,
    //      i.e. differenceMatrix(i,j) indexes [1 - cosine distance of (candidate(i,:), query(j,:))]
    // -------------------------------------------------------------------------
    Mat computeDifferenceMatrix(const Mat &candidate)
    {
        Mat differenceMatrix;
        if (bSetQuery) {
            Mat temp(candidate.rows, candidate.cols);
            temp.copy(candidate);
            if (bUseZNormalize) {
                temp.zNormalizeEachCol();
            }
            temp.sqr();
            Mat candidateNormalization = temp.sum(false);
            candidateNormalization.sqrt();
            Mat normalization = candidateNormalization.GEMM(queryNormalization);
            differenceMatrix = candidate.GEMM(queryTransposed);
            differenceMatrix.divide(normalization);
            
            // remove these next 3 lines for a similarity matrix instead
            float factor = -1;
            float term = 1;
            vDSP_vsmsa(differenceMatrix.data, 1, &factor, &term, differenceMatrix.data, 1, differenceMatrix.size());
        }
        return differenceMatrix;
    }
    // -------------------------------------------------------------------------
    
    // -------------------------------------------------------------------------
    float dtw(const Mat &query, 
             const Mat &candidate, 
             Mat &differenceMatrix,
             Mat &dtwDistance,
             vector<int> &pathI,
             vector<int> &pathJ)
    {
        // calculate the dtw distance matrix
        Mat traceBack(differenceMatrix.rows, differenceMatrix.cols);
        dtwDistance = differenceMatrix;
        int subscriptRange = differenceMatrix.cols * range;
        float x, y, z;
        int i, j;
        for (i = 0; i < differenceMatrix.rows; i++) 
        {
            float *dist = dtwDistance.row(i);
            float *tb = traceBack.row(i);
            float minCost = INFINITY;
            //int k = max(0, subscriptRange - i);
            //for (j = max(0, i - subscriptRange); j < min(i + subscriptRange - 1, differenceMatrix.cols); j++, k++) 
            for (j = 0; j < differenceMatrix.cols; j++) 
            {
                if (i == 0 && j == 0) {
                    *dist = *(dtwDistance.data);
                    minCost = *dist;
                    continue;
                }
                
                /*
                // get distance for all branches
                if ((j - 1 < 0) || (k - 1 < 0))                     x = INFINITY;                     // horizontal
                else                                                x = dtwDistance.row(i)[j-1]; 
                if ((i - 1 < 0 )|| (k + 1 > 2 * subscriptRange))    y = INFINITY;                     // veritcal
                else                                                y = dtwDistance.row(i-1)[j];      
                if ((i - 1 < 0) || (j - 1 < 0))                     z = INFINITY;                     // diagonal
                else                                                z = dtwDistance.row(i-1)[j-1];
                */
                
                // get distance for all branches
                if (j - 1 < 0)                x = INFINITY;                     // horizontal
                else                          x = dtwDistance.row(i)[j-1]; 
                if (i - 1 < 0)                y = INFINITY;                     // veritcal
                else                          y = dtwDistance.row(i-1)[j];      
                if (i - 1 < 0 || j - 1 < 0)   z = INFINITY;                     // diagonal
                else                          z = dtwDistance.row(i-1)[j-1];
                
                
                // find minimum branch and store path
                float val;
                if (x < y) {        // horizontal
                    val = x;
                    tb[j] = 0;
                }
                else {              // vertical
                    val = y;
                    tb[j] = 1;
                }
                if (z < val) {      // diagonal
                    val = z;
                    tb[j] = 2;
                }
                
                // aggregate distance
                dist[j] = val + dist[j];
                
                if (dist[j] < minCost) {
                    minCost = dist[j];
                }
            }
            
            // abandon early
            if (minCost > bestSoFar) {
                return INFINITY;
            }
        }
        
        // calculate path
        i--;
        j--;
        while(i >= 0 && j >= 0) 
        {
            pathI.push_back(i);
            pathJ.push_back(j);
            float t = traceBack.row(i)[j];
            if (t == 0) {                   // horizontal
                j--;
            }
            else if (t == 1) {              // vertical
                i--;
            }
            else {                          // diagonal
                i--;
                j--;
            }
        }
        return *(dtwDistance.last());
    }
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // Calculates the Sakoe-Chiba Band for a multidimensional input T x D
    //
    //  'input' is a T x D matrix (untouched, though not declared const since
    //  vDSP's max/min functions are not const) with:
    // 
    //  T frames, or time-steps
    //  D dimensions
    //
    //  [ d1 d2 .  . dn ]  t1
    //  [ .  .  .  .  . ]  t2
    //  [ .  .  .  .  . ]   .  time
    //  [ .  .  .  .  . ]   .
    //  [ .  .  .  .  . ]  tm
    //         dims
    //
    // 'upperBound' is computed as: UW_i = max(C_max(1,i-r), . . . , C_min(i+r,n)) and
    // 'lowerBound' is computed as: LW_i = min(C_max(1,i-r), . . . , C_min(i+r,n))
    // -------------------------------------------------------------------------
    void calculateBounds(Mat &input, 
                         Mat &upperBound, 
                         Mat &lowerBound);

    
    
    
private:
    // -------------------------------------------------------------------------
    float           bestSoFar;
    float           range;
    Mat             query, queryTransposed, queryNormalization;
    vector<Mat>     candidates;
    Mat             queryLB;
    Mat             queryUB;
    // -------------------------------------------------------------------------
    
    // -------------------------------------------------------------------------
    bool            bUseZNormalize, bSetQuery, bHaveCandidates;
    // -------------------------------------------------------------------------
};